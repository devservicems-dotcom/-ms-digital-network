# MS Digital Network (MSDN)

Maquette interactive et responsive en français pour présenter le projet MSDN.

## Tester localement
Ouvrir `index.html` dans un navigateur.

## Publier sur GitHub Pages
1. Ajouter `index.html` et `README.md` à la racine du dépôt GitHub.
2. Ouvrir **Settings → Pages**.
3. Dans **Build and deployment**, choisir **Deploy from a branch**.
4. Sélectionner la branche `main` et le dossier `/ (root)`, puis enregistrer.
5. Attendre la publication et ouvrir l'URL fournie par GitHub Pages.

## Important
Cette version est une maquette front-end. Les chiffres et contenus sont fictifs. Elle ne fournit pas d'authentification, de base de données, de paiements, de retraits, de commissions ni d'administration sécurisée. Ces fonctions demandent un backend et une configuration de sécurité adaptés.
