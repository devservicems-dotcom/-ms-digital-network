// MS Digital Network — front-end V1. Données financières et droits sensibles exclus du client.
import { initializeApp } from "https://www.gstatic.com/firebasejs/11.6.0/firebase-app.js";
import { getAuth, onAuthStateChanged, createUserWithEmailAndPassword, signInWithEmailAndPassword, sendEmailVerification, sendPasswordResetEmail, updateProfile, signOut } from "https://www.gstatic.com/firebasejs/11.6.0/firebase-auth.js";
import { getDatabase, ref, get, set, push, serverTimestamp } from "https://www.gstatic.com/firebasejs/11.6.0/firebase-database.js";
import { firebaseConfig } from "./firebase-config.js";

const app = initializeApp(firebaseConfig), auth = getAuth(app), db = getDatabase(app);
const $ = id => document.getElementById(id);
let authMode="signup", currentProfile={}, selectedPass="";
// Après vérification, Firebase revient sur le domaine Netlify autorisé.
// Garder etweb.netlify.app dans Authentication > Settings > Authorized domains.
const verificationSettings = {
  url: "https://etweb.netlify.app/?emailVerification=complete",
  handleCodeInApp: false
};
const titles={dashboard:"Tableau de bord",subscriptions:"Mes abonnements",profile:"Mon profil",notifications:"Notifications",academy:"Académie",ebooks:"E-books",marketplace:"Marketplace",tasks:"Tâches & visibilité",vcf:"Réseau VCF",affiliate:"Affiliation & filleuls",events:"Événements",messages:"Messagerie",wallet:"Mon portefeuille",history:"Historique",support:"Support & assistance"};
const passData=[
 {name:"Starter",price:"2 000",tag:"DÉCOUVERTE",desc:"Pour découvrir les ressources essentielles et commencer à participer au réseau."},
 {name:"VIP",price:"5 000",tag:"DÉVELOPPEMENT",desc:"Pour approfondir ses compétences et explorer davantage de services numériques."},
 {name:"Elite",price:"10 000",tag:"AVANCÉ",desc:"Pour les membres qui souhaitent un parcours plus avancé et des options supplémentaires."},
 {name:"Mentorat",price:"50 000",tag:"ACCOMPAGNEMENT",desc:"Pour bénéficier d’un accompagnement personnalisé autour de son projet."}
];
function escapeHTML(v=""){return String(v).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
function showPublic(){$("publicView").hidden=false;$("memberView").hidden=true;$("verificationView").hidden=true;document.body.classList.remove("signed-in");}
function showVerification(user){
  $("publicView").hidden=true;$("memberView").hidden=true;$("verificationView").hidden=false;
  $("verificationEmail").textContent=user.email||"votre adresse e-mail";
  document.body.classList.remove("signed-in");
}
function showMember(user){$("publicView").hidden=true;$("verificationView").hidden=true;$("memberView").hidden=false;document.body.classList.add("signed-in");$("memberEmail").textContent=user.email||"";$("memberName").textContent=currentProfile.name||user.displayName||"Membre";renderPage("dashboard");}
function openAuth(mode,pass=""){
  authMode=mode;selectedPass=pass;
  const signup=mode==="signup", reset=mode==="reset";
  $("authTitle").textContent=signup?"Créer un compte":reset?"Mot de passe oublié":"Se connecter";
  $("authEyebrow").textContent=signup?"REJOINDRE LE RÉSEAU":reset?"RÉCUPÉRATION":"ACCÈS MEMBRE";
  $("authDescription").textContent=signup?"Créez votre compte avec votre e-mail et un mot de passe. Un e-mail de vérification sera envoyé avant l’accès à votre espace.":reset?"Entrez l’adresse e-mail de votre compte. Nous vous enverrons un lien pour choisir un nouveau mot de passe.":"Entrez votre adresse e-mail et votre mot de passe. Après vérification de votre adresse lors de l’inscription, vous pourrez vous connecter avec votre mot de passe.";
  $("nameLabel").hidden=!signup;$("authName").hidden=!signup;$("authName").required=signup;
  $("passwordLabel").hidden=reset;$("authPassword").hidden=reset;$("authPassword").required=!reset;
  $("forgotPassword").hidden=signup||reset;
  $("sendLink").textContent=signup?"Créer mon compte":reset?"Envoyer le lien de réinitialisation":"Se connecter";
  $("switchAuth").hidden=reset;
  $("switchAuth").firstChild.textContent=signup?"Déjà membre ? ":"Nouveau sur la plateforme ? ";
  $("switchMode").textContent=signup?"Se connecter":"Créer un compte";
  $("authMessage").textContent="";$("authDialog").showModal();
}
function authErrorMessage(error){
 const code=error?.code||"";
 const messages={
  "auth/email-already-in-use":"Cette adresse e-mail possède déjà un compte. Essayez de vous connecter.",
  "auth/invalid-email":"L’adresse e-mail n’est pas valide.",
  "auth/weak-password":"Choisissez un mot de passe d’au moins 6 caractères.",
  "auth/invalid-credential":"E-mail ou mot de passe incorrect.",
  "auth/user-not-found":"Aucun compte trouvé avec cette adresse e-mail.",
  "auth/wrong-password":"Mot de passe incorrect.",
  "auth/too-many-requests":"Trop de tentatives. Réessayez plus tard.",
  "auth/network-request-failed":"Connexion réseau impossible. Vérifiez Internet.",
  "auth/operation-not-allowed":"La méthode e-mail/mot de passe n’est pas activée dans Firebase Authentication.",
  "auth/unauthorized-continue-uri":"L’adresse de retour n’est pas autorisée dans Firebase Authentication."
 };
 return messages[code]||"Opération impossible. Vérifiez la configuration Firebase et réessayez.";
}
async function finishVerificationReturn(user){
 if(!user)return false;
 const params=new URLSearchParams(location.search);
 if(params.get("emailVerification")!=="complete")return false;
 try{await user.reload();}catch(e){console.error(e);}
 if(auth.currentUser?.emailVerified){
   sessionStorage.removeItem("msVerifyOnLogin");
   history.replaceState({},document.title,location.pathname);
   return true;
 }
 return false;
}
async function checkVerifiedNow(){
 const user=auth.currentUser;
 if(!user){$("verificationMessage").textContent="Reconnectez-vous avec votre e-mail et votre mot de passe.";return;}
 const btn=$("checkVerification");btn.disabled=true;
 try{
   await user.reload();
   if(auth.currentUser?.emailVerified){
     sessionStorage.removeItem("msVerifyOnLogin");
     const params=new URLSearchParams(location.search);
     if(params.has("emailVerification"))history.replaceState({},document.title,location.pathname);
     await updateAuthScreen(auth.currentUser);
   }else{
     $("verificationMessage").textContent="La vérification n’est pas encore détectée. Ouvrez le lien reçu par e-mail, puis réessayez.";
   }
 }catch(e){console.error(e);$("verificationMessage").textContent="Vérification impossible pour le moment. Vérifiez votre connexion Internet.";}
 finally{btn.disabled=false;}
}
function card(title,desc,cta="Consulter",page="support"){
 const icons={academy:"▤",ebooks:"▧",marketplace:"⌘",tasks:"✓",support:"✦",profile:"♙",events:"◷",vcf:"◎",affiliate:"♧",messages:"✉",wallet:"◈",history:"↻",notifications:"♢"};
 const names={academy:"academy",ebooks:"ebooks",marketplace:"marketplace",tasks:"tasks",support:"support",profile:"profile",events:"events",vcf:"vcf",affiliate:"affiliate",messages:"messages",wallet:"wallet",history:"history",notifications:"notifications"};
 return `<article class="content-card module-tile tile-${names[page]||"default"}"><div class="tile-heading"><span class="tile-art" aria-hidden="true">${icons[page]||"✦"}</span><span class="tile-kicker">MS DIGITAL NETWORK</span></div><h3>${title}</h3><p class="muted">${desc}</p><button class="btn btn-outline module-action" data-target="${page}">${cta} <span aria-hidden="true">↗</span></button></article>`;
}
function renderPage(page){$("pageTitle").textContent=titles[page]||"Espace membre";document.querySelectorAll("[data-page]").forEach(b=>b.classList.toggle("active",b.dataset.page===page));const c=$("pageContent");
const modules={
 subscriptions:`<div class="module-intro"><span class="eyebrow">PASS À VIE</span><h2>Mes abonnements</h2><p class="muted">Choisissez un Pass à paiement unique. L’accès ne sera activé qu’après confirmation effective du paiement par le service sécurisé.</p></div><div class="module-grid">${passData.map((p,i)=>`<article class="content-card"><span class="eyebrow">${escapeHTML(p.tag)}</span><h3>${escapeHTML(p.name)}</h3><h2>${escapeHTML(p.price)} FCFA</h2><p class="muted">${escapeHTML(p.desc)}</p><p class="muted">Paiement unique · Accès à vie</p><button class="btn btn-primary pass-request" data-pass="${["starter","vip","elite","mentorat"][i]}">Demander ce Pass</button></article>`).join("")}</div><div class="content-card"><h3>État de la demande</h3><p class="muted">Cette version peut préparer une demande de Pass, mais ne confirme aucun paiement et n’active pas automatiquement l’abonnement.</p><p id="passRequestMsg" role="status" class="muted"></p></div>`,
 dashboard:`<section class="welcome"><small>VOTRE ESPACE PERSONNEL</small><h1>Bonjour ${escapeHTML(currentProfile.name||auth.currentUser?.displayName||"Membre")} 👋</h1><p>Bienvenue dans votre écosystème digital. Consultez les modules disponibles et les informations de votre compte.</p></section><div class="stat-grid dashboard-stat-grid"><div class="stat-card"><small>Mon Pass</small><strong>${escapeHTML(currentProfile.pass||"Aucun Pass confirmé")}</strong><small>Activation après validation</small></div><div class="stat-card"><small>État du compte</small><strong>Connecté</strong><small>Authentification Firebase</small></div></div><section class="wallet-preview"><div class="wallet-preview-head"><div><span class="eyebrow">ESPACE FINANCIER</span><h2>Mes soldes virtuels</h2><p>Chaque solde est affiché séparément.</p></div><span class="wallet-mark" aria-hidden="true">◈</span></div><div class="wallet-preview-grid"><div class="wallet-mini"><small>Solde principal</small><strong>0 FCFA</strong></div><div class="wallet-mini"><small>Récompenses</small><strong>0 FCFA</strong></div><div class="wallet-mini"><small>Affiliation</small><strong>0 FCFA</strong></div><div class="wallet-mini"><small>Retrait fictif</small><strong>0 FCFA</strong></div></div><button class="btn btn-outline module-action wallet-open" data-target="wallet">Voir mon portefeuille <span aria-hidden="true">↗</span></button><p class="wallet-disclaimer">Soldes de démonstration uniquement — aucun fonds réel ni retrait actif.</p></section><div class="module-grid module-grid-home">${card("Académie","Formations et apprentissages numériques.","Ouvrir","academy")}${card("E-books","Guides et bibliothèque numérique.","Voir le catalogue","ebooks")}${card("Marketplace","Catalogue de produits et prestations.","Explorer","marketplace")}${card("Tâches & visibilité","Consulter les missions disponibles.","Voir les tâches","tasks")}</div>`,
 profile:`<div class="content-card"><h3>Mes informations</h3><p class="muted">Modifiez les informations de base de votre profil.</p><form id="profileForm" class="module-form"><label for="profileName">Nom complet</label><input id="profileName" maxlength="80" required value="${escapeHTML(currentProfile.name||"")}"><label>Adresse e-mail</label><input value="${escapeHTML(auth.currentUser?.email||"")}" disabled><label for="profileCity">Ville (facultatif)</label><input id="profileCity" maxlength="80" value="${escapeHTML(currentProfile.city||"")}" placeholder="Ex. : Zinder"><label for="profileBio">Présentation (facultatif)</label><textarea id="profileBio" maxlength="300" rows="3">${escapeHTML(currentProfile.bio||"")}</textarea><label class="consent-line"><input type="checkbox" id="profileVcf" ${currentProfile.vcfConsent===true?"checked":""}> J’accepte que les champs de contact que je choisis de partager apparaissent dans le réseau membre (consentement modifiable).</label><button class="btn btn-primary" type="submit">Enregistrer mon profil</button><p id="profileMsg" class="muted" role="status"></p></form></div>`,
 notifications:`<h2>Notifications</h2><div class="content-card"><p class="muted">Les annonces et notifications personnalisées seront disponibles lorsque le service de gestion sera activé. Pour l’instant, consultez les annonces officielles communiquées par le support.</p><a class="inline-link" href="mailto:devservicems@gmail.com">Contacter le support →</a></div>`,
 academy:`<div class="module-intro"><span class="eyebrow">APPRENDRE ET PROGRESSER</span><h2>MS Digital Academy</h2><p class="muted">Espace de formations et de ressources numériques. Le catalogue de cours sera publié progressivement.</p></div><div class="module-grid">${card("Compétences numériques","Initiation aux outils et méthodes numériques.","Être informé","support")}${card("Marketing digital","Découvrir les bases de la communication en ligne.","Être informé","support")}${card("Création de contenu","Structurer des idées et créer des contenus utiles.","Être informé","support")}${card("Projets & entrepreneuriat","Organiser une idée et préparer un projet.","Être informé","support")}</div><p class="muted">Les titres sont des catégories prévues, pas des cours déjà accessibles.</p>`,
 ebooks:`<div class="module-intro"><span class="eyebrow">BIBLIOTHÈQUE NUMÉRIQUE</span><h2>E-books & ressources</h2><p class="muted">Une bibliothèque pour les guides, tutoriels et supports téléchargeables. Les fiches seront ajoutées après publication des contenus.</p></div><div class="module-grid">${card("Guides pratiques","Documents pédagogiques et fiches utiles.","Demander des infos","support")}${card("Tutoriels","Supports étape par étape.","Demander des infos","support")}${card("Ressources membres","Contenus accessibles selon les droits confirmés.","Voir les Pass","support")}</div>`,
 marketplace:`<div class="module-intro"><span class="eyebrow">CATALOGUE DE SERVICES</span><h2>Marketplace</h2><p class="muted">Découvrez les catégories prévues pour les produits numériques et les prestations. Les commandes réelles ne sont pas encore activées.</p></div><div class="module-grid">${card("Produits numériques","E-books, modèles et ressources.","En préparation","support")}${card("Services technologiques","Conception et assistance numérique.","En préparation","support")}${card("Prestations sur mesure","Présentez votre besoin au support.","Contacter","support")}</div>`,
 tasks:`<div class="module-intro"><span class="eyebrow">CAMPAGNES PARTICIPATIVES</span><h2>Tâches & visibilité</h2><p class="muted">Les missions sont publiées et validées par l’équipe. Aucun gain n’est garanti. Ne soumettez que des preuves que vous êtes autorisé à partager.</p></div><div class="content-card"><h3>Soumettre une preuve de mission</h3><p class="muted">Utilisez ce formulaire uniquement si le fondateur vous a donné une mission et un code de tâche. La demande sera enregistrée comme « en attente »; elle ne crédite aucun solde automatiquement.</p><form id="taskForm" class="module-form"><label for="taskCode">Code / nom de la tâche</label><input id="taskCode" maxlength="100" required placeholder="Code fourni par le fondateur"><label for="taskProof">Lien ou description de la preuve</label><textarea id="taskProof" rows="3" maxlength="1000" required placeholder="Lien autorisé ou explication courte"></textarea><button class="btn btn-primary" type="submit">Envoyer pour vérification</button><p id="taskMsg" class="muted" role="status"></p></form></div><div class="content-card"><h3>Mes soumissions</h3><div id="mySubmissions" class="muted">Chargement…</div></div>`,
 vcf:`<div class="module-intro"><span class="eyebrow">COMMUNAUTÉ</span><h2>Réseau professionnel VCF</h2><p class="muted">Les coordonnées privées ne seront pas affichées sans consentement. Le répertoire sera ouvert après la mise en place des contrôles de confidentialité.</p></div><div class="content-card"><h3>Votre consentement</h3><p class="muted">Vous pouvez choisir dans « Mon profil » si vous acceptez de partager une fiche de présentation dans le réseau. L’annuaire complet n’est pas encore activé.</p><button class="btn btn-outline module-action" data-target="profile">Gérer mon profil →</button></div>`,
 affiliate:`<div class="module-intro"><span class="eyebrow">RECOMMANDATIONS</span><h2>Affiliation & filleuls</h2><p class="muted">Le programme est en préparation. Ses critères, taux, délais et règles de validation seront publiés avant activation.</p></div><div class="content-card"><h3>Votre code membre</h3><p class="muted">Votre identifiant peut être communiqué au support pour faciliter les demandes d’assistance. Il ne constitue pas un lien rémunéré actif.</p><div class="ref-code">${escapeHTML(auth.currentUser?.uid||"")}</div><button class="btn btn-outline" id="copyRef">Copier mon identifiant</button><p id="copyMsg" class="muted"></p></div>`,
 events:`<div class="module-intro"><span class="eyebrow">RENCONTRES ET ACTIVITÉS</span><h2>Événements</h2><p class="muted">Les ateliers, séances d’information et rencontres seront annoncés officiellement lorsqu’ils seront programmés.</p></div>${card("Prochaines activités","Aucun événement publié pour le moment.","Contacter le support","support")}`,
 messages:`<div class="module-intro"><span class="eyebrow">ÉCHANGES</span><h2>Messagerie</h2><p class="muted">La messagerie interne nécessite encore des contrôles de confidentialité et de modération. En attendant, utilisez le support officiel.</p></div><div class="content-card"><a class="btn btn-primary" href="https://wa.me/22793533927" target="_blank" rel="noopener">Contacter le support WhatsApp ↗</a></div>`,
 wallet:`<div class="module-intro wallet-intro"><span class="eyebrow">ESPACE FINANCIER</span><h2>Mon portefeuille</h2><p class="muted">Retrouvez chaque catégorie de solde dans un seul espace. Les montants ci-dessous sont fictifs et séparés.</p></div><section class="wallet-page-panel"><div class="wallet-page-heading"><div><span class="eyebrow">APERÇU DU COMPTE</span><h3>Mes soldes virtuels</h3></div><span class="wallet-mark" aria-hidden="true">◈</span></div><div class="wallet-balance-grid"><article class="wallet-balance-card balance-main"><span class="balance-icon" aria-hidden="true">◈</span><small>Solde principal</small><strong>0 <em>FCFA</em></strong><p>Solde virtuel de démonstration.</p></article><article class="wallet-balance-card balance-rewards"><span class="balance-icon" aria-hidden="true">✦</span><small>Solde récompenses</small><strong>0 <em>FCFA</em></strong><p>Récompenses éventuelles après validation.</p></article><article class="wallet-balance-card balance-affiliate"><span class="balance-icon" aria-hidden="true">♧</span><small>Solde affiliation</small><strong>0 <em>FCFA</em></strong><p>Programme en préparation, aucune commission active.</p></article><article class="wallet-balance-card balance-withdraw"><span class="balance-icon" aria-hidden="true">⇧</span><small>Solde retrait fictif</small><strong>0 <em>FCFA</em></strong><p>Valeur de simulation, non retirable.</p></article></div><p class="wallet-disclaimer">Important : ces soldes ne représentent pas de l’argent réel. Aucun dépôt, paiement, transfert ou retrait n’est actif dans cette version.</p></section><div class="content-card wallet-history-card"><div><h3>Historique des opérations</h3><p class="muted">L’historique réel sera disponible lorsqu’un système sécurisé de gestion sera activé.</p></div><button class="btn btn-outline module-action" data-target="history">Consulter l’historique <span aria-hidden="true">↗</span></button></div>`,
 history:`<div class="module-intro"><span class="eyebrow">SUIVI DU COMPTE</span><h2>Historique</h2></div><div class="content-card"><p class="muted">Aucune transaction réelle n’est disponible. Les historiques seront affichés après la mise en place d’un service sécurisé de gestion des commandes et validations.</p></div>`,
 support:`<div class="module-intro"><span class="eyebrow">NOUS SOMMES À VOTRE ÉCOUTE</span><h2>Support & assistance</h2><p class="muted">Pour une question sur le compte, les Pass ou les services, contactez le support officiel.</p></div><div class="module-grid"><div class="content-card"><h3>Courriel</h3><p class="muted">devservicems@gmail.com</p><a class="btn btn-outline" href="mailto:devservicems@gmail.com">Envoyer un e-mail ↗</a></div><div class="content-card"><h3>WhatsApp</h3><p class="muted">+227 93 53 39 27</p><a class="btn btn-primary" href="https://wa.me/22793533927" target="_blank" rel="noopener">Ouvrir WhatsApp ↗</a></div></div>`
};c.innerHTML=modules[page]||modules.dashboard;$("drawer").classList.remove("open");bindPage(page);}
function bindPage(page){document.querySelectorAll(".module-action").forEach(b=>b.addEventListener("click",()=>renderPage(b.dataset.target)));if(page==="profile"){$("profileForm").addEventListener("submit",saveProfile);}if(page==="subscriptions"){document.querySelectorAll(".pass-request").forEach(b=>b.addEventListener("click",()=>requestPass(b.dataset.pass)));}if(page==="tasks"){ $("taskForm").addEventListener("submit",submitTask);loadSubmissions();}if(page==="affiliate"){$("copyRef").addEventListener("click",async()=>{try{await navigator.clipboard.writeText(auth.currentUser.uid);$("copyMsg").textContent="Identifiant copié.";}catch{$("copyMsg").textContent="Copie indisponible sur ce navigateur.";}});}}

async function requestPass(passCode){
 const msg=$("passRequestMsg");const user=auth.currentUser;
 if(!user||!user.emailVerified){msg.textContent="Vérifiez votre adresse e-mail avant de continuer.";return;}
 const button=document.querySelector(`.pass-request[data-pass="${passCode}"]`);if(button)button.disabled=true;msg.textContent="Préparation de la demande…";
 try{
  const token=await user.getIdToken(true);
  const response=await fetch("/.netlify/functions/pass-intent",{method:"POST",headers:{"Content-Type":"application/json","Authorization":`Bearer ${token}`},body:JSON.stringify({passCode})});
  const data=await response.json().catch(()=>({}));
  if(!response.ok)throw new Error(data.message||"Le serveur n’est pas encore configuré pour traiter cette demande.");
  msg.textContent="Demande enregistrée. Le paiement et l’activation restent en attente de vérification.";
 }catch(error){msg.textContent=error.message||"Demande impossible pour le moment.";}finally{if(button)button.disabled=false;}
}
async function saveProfile(e){e.preventDefault();const msg=$("profileMsg");msg.textContent="Enregistrement…";const data={name:$("profileName").value.trim(),city:$("profileCity").value.trim(),bio:$("profileBio").value.trim(),vcfConsent:$("profileVcf").checked,updatedAt:Date.now()};try{await set(ref(db,`users/${auth.currentUser.uid}/profile`),data);currentProfile={...currentProfile,...data};$("memberName").textContent=data.name||"Membre";msg.textContent="Profil enregistré.";}catch(err){console.error(err);msg.textContent="Enregistrement refusé. Vérifiez les règles Firebase Realtime Database.";}}
async function submitTask(e){e.preventDefault();const msg=$("taskMsg");const user=auth.currentUser;if(!user||!user.emailVerified){msg.textContent="Connectez-vous avec une adresse e-mail vérifiée.";return;}const taskCode=$("taskCode").value.trim(),proof=$("taskProof").value.trim();if(!taskCode||taskCode.length>100||!proof||proof.length>1000){msg.textContent="Vérifiez le code et la preuve (longueur maximale : 100 et 1 000 caractères).";return;}const submitButton=$("taskForm").querySelector('button[type="submit"]');if(submitButton)submitButton.disabled=true;msg.textContent="Envoi sécurisé…";try{const token=await user.getIdToken();const response=await fetch("/.netlify/functions/task-submit",{method:"POST",headers:{"Content-Type":"application/json","Authorization":`Bearer ${token}`},body:JSON.stringify({taskCode,proof})});const data=await response.json().catch(()=>({}));if(!response.ok)throw new Error(data.message||"Envoi impossible pour le moment.");$("taskForm").reset();msg.textContent=data.message||"Preuve envoyée pour vérification.";loadSubmissions();}catch(err){msg.textContent=err.message||"Service indisponible. Réessayez plus tard.";}finally{if(submitButton)submitButton.disabled=false;}}
async function loadSubmissions(){const box=$("mySubmissions");try{const snap=await get(ref(db,`taskSubmissions/${auth.currentUser.uid}`));if(!snap.exists()){box.textContent="Aucune soumission pour le moment.";return;}box.innerHTML=Object.values(snap.val()).map(x=>`<div class="submission-row"><b>${escapeHTML(x.taskCode||"Tâche")}</b><span class="pending">${x.status==="pending"?"En attente":"Statut : "+escapeHTML(x.status)}</span><small>${new Date(x.submittedAt||Date.now()).toLocaleDateString("fr-FR")}</small></div>`).join("");}catch{box.textContent="Impossible de charger les soumissions. Vérifiez les règles Firebase.";}}
$("loginTop").addEventListener("click",()=>openAuth("login"));
["signupTop","signupHero","signupBottom"].forEach(id=>$(id).addEventListener("click",()=>openAuth("signup")));
document.querySelectorAll(".passSignup").forEach((b,i)=>b.addEventListener("click",()=>openAuth("signup",passData[i]?.name||"")));
$("switchMode").addEventListener("click",()=>openAuth(authMode==="signup"?"login":"signup"));
$("forgotPassword").addEventListener("click",()=>openAuth("reset"));
$("sendLink").addEventListener("click",async()=>{
 const email=$("authEmail").value.trim(),name=$("authName").value.trim(),password=$("authPassword").value;
 if(!email||(authMode==="signup"&&!name)||(authMode!=="reset"&&!password)){ $("authMessage").textContent="Veuillez remplir les champs requis.";return; }
 $("sendLink").disabled=true;$("authMessage").textContent="Traitement en cours…";
 try{
  if(authMode==="reset"){
    await sendPasswordResetEmail(auth,email);
    $("authMessage").textContent="Si un compte correspond à cette adresse, un lien de réinitialisation a été envoyé. Vérifiez aussi le dossier Spam.";
  }else if(authMode==="signup"){
    const credential=await createUserWithEmailAndPassword(auth,email,password);
    if(name)await updateProfile(credential.user,{displayName:name});
    await set(ref(db,`users/${credential.user.uid}/profile`),{name,city:"",bio:"",vcfConsent:false,createdAt:Date.now(),updatedAt:Date.now()});
    sessionStorage.setItem("msVerifyOnLogin","true");
    await sendEmailVerification(credential.user,verificationSettings);
    $("authMessage").textContent="Compte créé. Ouvrez l’e-mail de vérification puis cliquez sur le lien pour accéder à votre espace. Vérifiez le dossier Spam si nécessaire.";
  }else{
    const credential=await signInWithEmailAndPassword(auth,email,password);
    if(credential.user.emailVerified){
      sessionStorage.removeItem("msVerifyOnLogin");
      $("authMessage").textContent="Connexion réussie. Ouverture de votre espace membre…";
      $("authDialog").close();
      await updateAuthScreen(credential.user);
    }else{
      sessionStorage.setItem("msVerifyOnLogin","true");
      await sendEmailVerification(credential.user,verificationSettings);
      $("authMessage").textContent="Votre adresse e-mail n’est pas encore vérifiée. Un e-mail vient d’être envoyé. Ouvrez le lien, revenez sur le site, puis appuyez sur « J’ai vérifié mon e-mail ».";
    }
  }
 }catch(e){if(authMode==="login"&&!auth.currentUser)sessionStorage.removeItem("msVerifyOnLogin");console.error(e);$("authMessage").textContent=authErrorMessage(e);}
 finally{$("sendLink").disabled=false;}
});
$("checkVerification").addEventListener("click",checkVerifiedNow);
$("resendVerification").addEventListener("click",async()=>{
 const user=auth.currentUser;if(!user){$("verificationMessage").textContent="Reconnectez-vous avec votre e-mail et votre mot de passe.";return;}
 $("resendVerification").disabled=true;
 try{await sendEmailVerification(user,verificationSettings);$("verificationMessage").textContent="Un nouvel e-mail de vérification a été envoyé. Vérifiez aussi le dossier Spam.";}
 catch(e){console.error(e);$("verificationMessage").textContent=authErrorMessage(e);}
 finally{$("resendVerification").disabled=false;}
});
$("verificationLogout").addEventListener("click",async()=>{sessionStorage.removeItem("msVerifyOnLogin");await signOut(auth);currentProfile={};showPublic();});
$("logoutBtn").addEventListener("click",async()=>{sessionStorage.removeItem("msVerifyOnLogin");await signOut(auth);currentProfile={};showPublic();window.scrollTo(0,0);});
$("drawerToggle").addEventListener("click",()=>$("drawer").classList.toggle("open"));
$("menuToggle").addEventListener("click",()=>{document.querySelector(".desktop-nav")?.classList.toggle("mobile-open");document.querySelector(".desktop-nav")?.scrollIntoView({block:"nearest"});});
document.querySelectorAll("[data-page]").forEach(b=>b.addEventListener("click",()=>{if(auth.currentUser)renderPage(b.dataset.page);else openAuth("login");}));
window.addEventListener("click",e=>{if(e.target===$("authDialog"))$("authDialog").close();});
async function updateAuthScreen(user){
 if(!user){currentProfile={};showPublic();return;}
 await finishVerificationReturn(user);
 if(!auth.currentUser?.emailVerified){showVerification(user);return;}
 sessionStorage.removeItem("msVerifyOnLogin");
 try{const snap=await get(ref(db,`users/${user.uid}/profile`));currentProfile=snap.exists()?snap.val():{};showMember(user);}
 catch(e){console.error(e);currentProfile={};showMember(user);}
}
onAuthStateChanged(auth,user=>{updateAuthScreen(user);});
window.addEventListener("focus",()=>{if(auth.currentUser)updateAuthScreen(auth.currentUser);});
document.addEventListener("visibilitychange",()=>{if(!document.hidden&&auth.currentUser)updateAuthScreen(auth.currentUser);});
