// Configuration Web Firebase — MS Digital Network
// Ne jamais ajouter de clé privée ou de secret de prestataire ici.
export const firebaseConfig = {
  apiKey: "AIzaSyB70zb-CVp5PY6cOKdb-2zbpg42TCW7Qhk",
  authDomain: "ms-digital-network.firebaseapp.com",
  databaseURL: "https://ms-digital-network-default-rtdb.firebaseio.com",
  projectId: "ms-digital-network",
  appId: "1:299448754481:web:126dd767c74e89c8a39010",
  messagingSenderId: "299448754481"
};
