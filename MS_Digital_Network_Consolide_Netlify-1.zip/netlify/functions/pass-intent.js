import { initializeApp, getApps, cert } from "firebase-admin/app";
import { getAuth } from "firebase-admin/auth";
import { getDatabase } from "firebase-admin/database";

const PASS = {
  starter: { name: "Starter", amount: 2000 },
  vip: { name: "VIP", amount: 5000 },
  elite: { name: "Elite", amount: 10000 },
  mentorat: { name: "Mentorat", amount: 50000 },
};

function adminApp() {
  if (getApps().length) return getApps()[0];
  const raw = process.env.FIREBASE_SERVICE_ACCOUNT_JSON;
  const databaseURL = process.env.FIREBASE_DATABASE_URL;
  if (!raw || !databaseURL) throw new Error("Server Firebase non configuré");
  return initializeApp({ credential: cert(JSON.parse(raw)), databaseURL });
}

export default async (req, context) => {
  const headers = { "content-type": "application/json", "cache-control": "no-store" };
  if (req.method !== "POST") return new Response(JSON.stringify({ message: "Méthode non autorisée" }), { status: 405, headers });
  try {
    const app = adminApp();
    const authHeader = req.headers.get("authorization") || "";
    const token = authHeader.startsWith("Bearer ") ? authHeader.slice(7) : "";
    if (!token) return new Response(JSON.stringify({ message: "Authentification requise" }), { status: 401, headers });
    const user = await getAuth(app).verifyIdToken(token, true);
    if (user.email_verified !== true) return new Response(JSON.stringify({ message: "Adresse e-mail non vérifiée" }), { status: 403, headers });
    const body = await req.json();
    const passCode = String(body?.passCode || "").toLowerCase();
    const selected = PASS[passCode];
    if (!selected) return new Response(JSON.stringify({ message: "Pass invalide" }), { status: 400, headers });
    const ref = getDatabase(app).ref(`passRequests/${user.uid}`);
    const result = await ref.transaction(current => {
      if (current && ["pending", "review"].includes(current.status)) return;
      return { passCode, passName: selected.name, amount: selected.amount, currency: "XOF", status: "pending", requestedAt: Date.now(), userUid: user.uid, userEmail: user.email || "" };
    });
    if (!result.committed) return new Response(JSON.stringify({ message: "Une demande de Pass est déjà en attente de traitement." }), { status: 409, headers });
    return new Response(JSON.stringify({ ok: true, status: "pending", message: "Demande enregistrée en attente de vérification." }), { status: 201, headers });
  } catch (error) {
    console.error("pass-intent error", error?.message || "unknown");
    return new Response(JSON.stringify({ message: "Service temporairement indisponible ou non configuré." }), { status: 503, headers });
  }
};
