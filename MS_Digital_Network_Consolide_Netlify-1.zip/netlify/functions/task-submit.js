import { createHash } from "node:crypto";
import { initializeApp, getApps, cert } from "firebase-admin/app";
import { getAuth } from "firebase-admin/auth";
import { getDatabase } from "firebase-admin/database";

function adminApp() {
  if (getApps().length) return getApps()[0];
  const raw = process.env.FIREBASE_SERVICE_ACCOUNT_JSON;
  const databaseURL = process.env.FIREBASE_DATABASE_URL;
  if (!raw || !databaseURL) throw new Error("Server Firebase non configuré");
  return initializeApp({ credential: cert(JSON.parse(raw)), databaseURL });
}

const json = (status, body) => new Response(JSON.stringify(body), {
  status, headers: { "content-type": "application/json; charset=utf-8", "cache-control": "no-store", "x-content-type-options": "nosniff" }
});

export default async (req) => {
  if (req.method !== "POST") return json(405, { message: "Méthode non autorisée." });
  const length = Number(req.headers.get("content-length") || 0);
  if (length > 5000) return json(413, { message: "Demande trop volumineuse." });
  const authHeader = req.headers.get("authorization") || "";
  const token = authHeader.startsWith("Bearer ") ? authHeader.slice(7) : "";
  if (!token || token.length > 5000) return json(401, { message: "Authentification requise." });
  try {
    const app = adminApp();
    const user = await getAuth(app).verifyIdToken(token, true);
    if (user.email_verified !== true) return json(403, { message: "Vérifiez votre adresse e-mail." });
    const body = await req.json();
    const taskCode = String(body?.taskCode || "").trim();
    const proof = String(body?.proof || "").trim();
    if (!taskCode || taskCode.length > 100 || !proof || proof.length > 1000) {
      return json(400, { message: "Code de tâche ou preuve invalide." });
    }
    const normalized = taskCode.toLocaleLowerCase("fr").replace(/\s+/g, " ");
    const submissionId = createHash("sha256").update(normalized).digest("hex").slice(0, 40);
    const ref = getDatabase(app).ref(`taskSubmissions/${user.uid}/${submissionId}`);
    const result = await ref.transaction(current => {
      if (current !== null) return;
      return { taskCode, proof, status: "pending", submittedAt: Date.now(), userUid: user.uid };
    }, undefined, false);
    if (!result.committed) return json(409, { message: "Une soumission existe déjà pour ce code de tâche." });
    return json(201, { ok: true, status: "pending", message: "Preuve envoyée pour vérification. Aucun solde n’a été crédité." });
  } catch (error) {
    // Do not expose tokens, service-account details, or database errors to the client.
    console.error("task-submit error", error?.code || "server_error");
    if (error?.code === "auth/argument-error" || error?.code === "auth/invalid-id-token" || error?.code === "auth/id-token-expired" || error?.code === "auth/revoked-id-token") {
      return json(401, { message: "Session invalide. Reconnectez-vous." });
    }
    if (error instanceof SyntaxError) return json(400, { message: "Corps JSON invalide." });
    return json(503, { message: "Service temporairement indisponible ou non configuré." });
  }
};
