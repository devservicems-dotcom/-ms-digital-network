MS DIGITAL NETWORK — PACK COMPLET (SOCLE V1)
=============================================

Ce ZIP regroupe les fichiers du site dans un dossier racine prêt à être déployé sur un hébergement statique HTTPS comme Netlify. Les e-mails de vérification utilisent une URL de retour fixe vers https://etweb.netlify.app/?emailVerification=complete. Le site doit être publié sur ce domaine et celui-ci doit être présent dans Firebase Authentication > Settings > Authorized domains. La page comprend aussi un bouton pour recontrôler la vérification si le retour automatique ne se produit pas.

FICHIERS
--------
- index.html : page d’accueil et interface membre
- style.css : styles adaptatifs mobile / ordinateur
- app.js : interface, Firebase Authentication et Realtime Database
- firebase-config.js : configuration Web du projet Firebase ms-digital-network
- database.rules.example.json : exemple de règles RTDB à examiner et tester
- netlify.toml : configuration de publication statique Netlify

AUTHENTIFICATION INCLUSE
------------------------
- Création de compte avec nom, e-mail et mot de passe
- Envoi d’un e-mail de vérification après inscription
- Connexion avec e-mail et mot de passe
- À la connexion, accès direct si l’adresse est déjà vérifiée; un e-mail est envoyé uniquement si elle ne l’est pas encore
- Écran d’attente tant que la vérification requise n’est pas terminée
- Récupération du mot de passe par e-mail
- Déconnexion et accès à l’espace membre

À CONFIGURER DANS FIREBASE
--------------------------
1. Ouvrir Firebase Console et sélectionner ms-digital-network.
2. Dans Authentication > Sign-in method, activer Email/Password.
3. Dans Authentication > Settings > Authorized domains, vérifier que le domaine Netlify exact est présent (ex. etweb.netlify.app).
4. Dans Authentication > Templates, personnaliser au besoin les e-mails de vérification et de réinitialisation.
5. Vérifier que Realtime Database est créée et correspond à la databaseURL de firebase-config.js.
6. Examiner les règles dans database.rules.example.json, les tester dans Rules Simulator, puis les adapter aux chemins réellement utilisés avant publication. Ne pas publier des règles ouvertes.

DÉPLOIEMENT SUR NETLIFY DEPUIS ANDROID
--------------------------------------
1. Extraire le ZIP dans le gestionnaire de fichiers.
2. Ouvrir Netlify et choisir le site à mettre à jour.
3. Aller dans Deploys / Deploy manually si cette option est disponible.
4. Envoyer le dossier extrait qui contient directement index.html, app.js, style.css et firebase-config.js.
5. Attendre la fin du déploiement, ouvrir le domaine HTTPS et actualiser la page.
6. Tester l’inscription avec un compte de test, le clic sur l’e-mail de vérification, puis la connexion avec e-mail et mot de passe. Une adresse déjà vérifiée ne reçoit pas un nouvel e-mail à chaque connexion. Si l’adresse n’est pas encore vérifiée, ouvrez le lien reçu, revenez au site Netlify et appuyez sur « J’ai vérifié mon e-mail ». Testez aussi « Mot de passe oublié ». Les liens de vérification redirigent vers le domaine Netlify configuré dans app.js.

IMPORTANT — LIMITES ET SÉCURITÉ
-------------------------------
- Ce projet est un socle de développement, pas une application de production certifiée.
- Les sections Académie, e-books, Marketplace, tâches, affiliation, événements, messagerie et portefeuille présentent l’expérience et les modules prévus; les opérations d’administration, validations, paiements et récompenses ne sont pas intégralement connectées.
- Aucun paiement réel, dépôt, retrait, revenu ou transfert d’argent n’est activé. Les soldes de démonstration ne sont pas de l’argent réel.
- Les droits Fondateur / administrateur, approbations et modifications de soldes exigent une autorisation serveur sécurisée; ne jamais se fier à un simple rôle stocké côté navigateur ou modifiable par l’utilisateur.
- Les règles RTDB jointes sont un exemple de départ et doivent être testées avant utilisation.
- La vérification par e-mail et l’accès membre doivent être testés sur le domaine réellement publié. L’envoi d’e-mails peut aussi être soumis aux limites Firebase.
- La durée de session de 24 heures n’est pas garantie côté serveur par ce socle.
- Ne jamais mettre dans le code front-end de clé privée, mot de passe, clé de service Firebase Admin ou secret marchand.
- Pour toute activation future de paiement ou de retrait, utiliser un prestataire autorisé, les conditions applicables et une supervision adulte appropriée.

CONTACT
-------
E-mail : devservicems@gmail.com
WhatsApp : +227 93 53 39 27
Pass affichés : Starter 2 000 FCFA · VIP 5 000 FCFA · Elite 10 000 FCFA · Mentorat 50 000 FCFA

MISE À JOUR VISUELLE — MS DIGITAL NETWORK
Cette version comprend une feuille msdn-identity.css chargée après style.css.
Elle apporte une grille de modules à deux colonnes sur mobile, des cartes compactes
et différenciées, ainsi qu'une mise en page d'accueil plus dynamique. Le nom de
marque et les parcours Firebase existants sont conservés.

Important : les montants restent des valeurs de démonstration. Les paiements,
retraits, récompenses et modules signalés comme en préparation ne sont pas activés
par cette mise à jour graphique. Déployer ensemble tous les fichiers du ZIP.

MISE À JOUR — PORTEFEUILLE REGROUPÉ
-----------------------------------
Le tableau de bord présente maintenant un aperçu compact des soldes virtuels, et la page « Mon portefeuille » regroupe quatre catégories distinctes : solde principal, solde récompenses, solde affiliation et solde retrait fictif. Les montants sont des valeurs de démonstration fixes à 0 FCFA et ne sont pas connectés à un système de paiement ou de retrait. L’historique reste informatif tant que le service sécurisé de transactions n’est pas activé.


MISE À JOUR TECHNIQUE — NETLIFY FUNCTIONS ET DEMANDE DE PASS
-------------------------------------------------------------
- Une page « Mes abonnements » est disponible dans l’espace membre.
- Les Pass affichés sont Starter (2 000 XOF), VIP (5 000 XOF), Elite (10 000 XOF) et Mentorat (50 000 XOF), en paiement unique à vie.
- Une fonction Netlify `/.netlify/functions/pass-intent` permet de créer une demande en attente après vérification du jeton Firebase et de l’adresse e-mail. Le montant est déterminé côté serveur.
- Cette fonction ne traite pas de paiement, ne confirme aucune transaction et n’active aucun Pass. KomiPay et Chariow ne sont pas encore intégrés.
- Avant déploiement, installer les dépendances avec `npm install` et configurer dans l’environnement Netlify `FIREBASE_SERVICE_ACCOUNT_JSON` (JSON du compte de service Firebase, confidentiel) et `FIREBASE_DATABASE_URL`. Ne jamais placer ces valeurs dans les fichiers publics ou les envoyer dans le chat. La configuration du compte de service doit être faite par un adulte responsable autorisé.
- Appliquer et tester les règles RTDB fournies avec ce pack dans Firebase Console. Les demandes `passRequests` sont écrites par la fonction Admin SDK; les membres ne peuvent pas s’attribuer un Pass dans leur profil.
- Ce pack est une étape de développement et non une version de production finale. Tester les fonctions Netlify, les règles RTDB et les parcours d’authentification sur un site de préproduction avant publication.


SERVEUR NETLIFY — AJOUT DU TRAITEMENT DES TÂCHES
------------------------------------------------
- `netlify/functions/pass-intent.js` : demande de Pass avec jeton Firebase vérifié; n'active pas le Pass et ne confirme aucun paiement.
- `netlify/functions/task-submit.js` : vérifie le jeton Firebase côté serveur, exige un e-mail vérifié, valide les champs et enregistre la preuve avec un identifiant déterministe pour empêcher une deuxième soumission du même code par le même membre.
- Les écritures directes depuis le navigateur vers `taskSubmissions` sont interdites par l'exemple de règles RTDB; le serveur utilise Firebase Admin SDK. Les lectures restent limitées au membre concerné.
- Les deux fonctions ont besoin de `FIREBASE_SERVICE_ACCOUNT_JSON` et `FIREBASE_DATABASE_URL` définis dans les variables d'environnement Netlify. Ne jamais exposer ces secrets dans le site, le ZIP partagé publiquement ou le chat.
- Pour installer et vérifier localement : `npm install`, puis `npm run check`. Déployer depuis la racine du projet avec Node.js 18 ou plus récent.
- Cette étape n'inclut pas encore un espace administrateur pour approuver les tâches, un registre de missions, le crédit de récompenses, les paiements KomiPay/Chariow ou les retraits. Aucun argent réel n'est manipulé.
